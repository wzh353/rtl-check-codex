create_clock -name sys_clk -period 20 [get_ports {clk}]
